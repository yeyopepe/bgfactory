# 017 — Componente "cuadro de texto"

**Área**: Mesa de juego

Primer tipo de componente concreto: un bloque de texto con contenido, tamaño de fuente, color de texto y color de fondo configurables (fondo transparente por defecto). Se precarga automáticamente una instancia solo si no hay ningún estado guardado que recuperar (ni en el navegador ni embebido en el propio fichero) — ver [Persistencia y guardado](INDEX.md#persistencia-y-guardado).

- **Disponible en**: renderizado sobre la mesa en modo juego y modo edición.
- **Código**: 00002.
- **Desde**: 2026-07-17
- **Última modificación**: 2026-07-17
